﻿using UnityEngine;
using System.Collections;

public class Destoryer : MonoBehaviour {

	void DestoryGameObject() {
		Destroy (gameObject);
	}
}
